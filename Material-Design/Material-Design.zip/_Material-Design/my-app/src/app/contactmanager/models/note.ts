export class Note {
  id: number;
  title: string;
  data: Date;
}
