import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { DemoModule } from "./demo/demo.module";
import { ContactmanagerModule } from "./contactmanager/contactmanager.module";
import { AppRoutingModule } from "./app-routing.module";
import { Routes, RouterModule } from "@angular/router";

import { AppComponent } from "./app.component";

const routes: Routes = [
  {
    path: "contactmanager",
    loadChildren: "./contactmanager/contactmanager.module#ContactmanagerModule"
  },
  { path: "demo", loadChildren: "./demo/demo.module#DemoModule" },
  { path: "**", redirectTo: "contactmanager" }
];

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    DemoModule,
    ContactmanagerModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
