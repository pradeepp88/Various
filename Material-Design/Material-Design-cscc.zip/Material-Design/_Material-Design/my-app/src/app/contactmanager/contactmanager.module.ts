import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Routes, RouterModule } from "@angular/router";

import { ContactmanagerAppComponent } from "./contactmanager-app.component";
import { ToolbarComponent } from "./components/toolbar/toolbar.component";
import { MainContentComponent } from "./components/main-content/main-content.component";
import { SideNavComponent } from "./components/side-nav/side-nav.component";

import { MaterialModule } from "../shared/material.module";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { UserService } from "./services/user.service";
import { HttpClientModule } from "@angular/common/http";
import { NotesComponent } from "./components/notes/notes.component";
import { NewContactDialogComponent } from "./components/new-contact-dialog/new-contact-dialog.component";

const routes: Routes = [
  {
    path: "contactmanager",
    component: ContactmanagerAppComponent,
    children: [
      { path: ":id", component: MainContentComponent },
      { path: "", component: MainContentComponent }
    ]
  }
  //{ path: "**", redirectTo: "contactmanager" }
];

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    MaterialModule,
    FormsModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
    ContactmanagerAppComponent,
    ToolbarComponent,
    MainContentComponent,
    SideNavComponent,
    NotesComponent,
    NewContactDialogComponent
  ],
  entryComponents: [NewContactDialogComponent],
  providers: [UserService],
  exports: [RouterModule]
})
export class ContactmanagerModule {}
