import { Component, OnInit, NgZone } from "@angular/core";
import { UserService } from "../../services/user.service";
import { Observable } from "rxjs";
import { User } from "../../models/user";
import { Router } from "@angular/router";

const SMALL_WIDTH_BREAKPOINT = 720;

@Component({
  selector: "app-sidenav",
  templateUrl: "./side-nav.component.html",
  styleUrls: ["./side-nav.component.scss"]
})
export class SideNavComponent implements OnInit {
  //private mediaMatcher: MediaQueryList;

  users: Observable<User[]>;
  isDarkTheme: boolean = false;
  dir: string = 'ltr';
  constructor(
    zone: NgZone,
    private userService: UserService,
    private router: Router
  ) {
    // this.mediaMatcher.addListener(mql =>
    //   ///zone.run(() => this.mediaMatcher = mql))); //This is old code
    //   zone.run(
    //     () =>
    //       (this.mediaMatcher = matchMedia(
    //         `(max-width: ${SMALL_WIDTH_BREAKPOINT}px)`
    //       ))
    //   )
    // ); //This works!!
  }

  ngOnInit() {
    this.users = this.userService.users;
    this.userService.loadAll();

    this.router.events.subscribe(() => {});
  }

  isScreenSmall(): boolean {
    return true;
    //return this.mediaMatcher.matches;
  }
  toggleTheme(): void {
    this.isDarkTheme = !this.isDarkTheme;
  }
  toggleDir(): void {
    console.log(`toggleDir() event`);
    this.dir = this.dir === 'ltr' ? 'rtl' : 'ltr';
    //this.sidenav.toggle().then(() => this.sidenav.toggle());
  }
}
