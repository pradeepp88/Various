
var interval = setInterval(() => { 
    timer() 
  }, 1000);
  
 const timer = () => {    
    const dateVar = new Date();    
    const time = dateVar.toLocaleTimeString();         
    console.log(`timer:${time}`);
  }
   
  const stopFunction = () =>{
    clearInterval(interval);
  }

  interval; // not a function, a reference
  //stopFunction();