var http = require('http');
var firewall = require('./firewall');

http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json'});

    var rules = firewall.rulesModule;
    var logs = firewall.logsModule;

  if(req.url === '/') {
    res.end('No data found');
  }
  else if(req.url === '/firewall/allow') {

    var result = rules.allow();
    res.end(JSON.stringify(result));
  }
  else if(req.url === '/firewall/deny') {

    var result = rules.deny();
    res.end(JSON.stringify(result));
  }
  else if(req.url === '/firewall/remove') {
    var result = rules.remove();
    res.end(JSON.stringify(result));
  }
  else if(req.url === '/firewall/reset') {
    var result = rules.reset();
    res.end(JSON.stringify(result));
  }
  else if(req.url === '/firewall/rules') {
    var result = rules.getRules();
    res.end(JSON.stringify(result));
  }
  else if(req.url === '/firewall/logs') {
    var result = logs.getLogs();
    res.end(JSON.stringify(result));
  }
  else {
        // request not found, send back 404
        res.writeHead(404, 'error - page not found');
        res.end();
  }
  
}).listen(1337, '127.0.0.1');