
var rules = [];

var allow = function () {
    rules.push('ALLOW');
    return 'OK: ALLOW rule added';
}

var deny = function () {
    rules.push('DENY');
    return 'OK: deny rule added';
}

var remove = function () {
    if(rules.length <= 0) {
        return ("ERROR: rule array is empty, cannot remove")
        
    }
    rules.pop();
    return 'OK: status removed - rule length: ' + rules.length;
}
var reset = function () {
    rules = [];
    return 'OK: rules reset - rule length: ' + rules.length;
}
var getRules = function () {
    return rules;
}
module.exports = {
    allow: allow,
    deny: deny,
    remove: remove,
    reset: reset,
    getRules: getRules
}
