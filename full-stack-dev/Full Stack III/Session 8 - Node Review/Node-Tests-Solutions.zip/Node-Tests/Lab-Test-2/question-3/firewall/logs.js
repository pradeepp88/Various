

var getLogs = function () {
    return [
        {logdate:'2018-09-30', action: 'ALLOW', protocol: 'TCP'},
        {logdate:'2018-09-29', action: 'ALLOW', protocol: 'UDP'},
        {logdate:'2018-09-28', action: 'BLOCK', protocol: 'UDP'},
        {logdate:'2018-09-27', action: 'DENY', protocol: 'TCP'},
    ]
}

module.exports = {
    getLogs: getLogs
}