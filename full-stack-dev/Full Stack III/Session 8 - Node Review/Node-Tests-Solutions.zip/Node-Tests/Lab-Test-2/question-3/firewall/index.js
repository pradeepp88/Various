var logsModule = require('./logs');
var rulesModule = require('./rules');

module.exports = {
    logsModule: logsModule,
    rulesModule: rulesModule
}