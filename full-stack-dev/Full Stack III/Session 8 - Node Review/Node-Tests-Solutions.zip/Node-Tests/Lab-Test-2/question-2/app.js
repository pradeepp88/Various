// require built-in file system module
var fs = require('fs');

var rs = fs.createReadStream("data.txt");
var ws = fs.createWriteStream("output.txt");

rs.on("data", function(data) {
    console.log(data);
    console.log(data.toString());
    ws.write(data);
})

rs.on("end", function () {
    ws.close();
    console.log('write is completed!');
})

