var should = require('should');
var calc = require('./calculator');

describe('Calculator', function () {
    
    describe('when dividing two numbers', function () {
        
        it('should divide two numbers correctly 4/2 = 2', function () {
            calc.divideTwoNumbers(4, 2).should.equal(2);
        });
        it('should divide two numbers correctly 10/2 =5', function () {
            calc.divideTwoNumbers(10, 2).should.equal(5);
        });
        it('divide two numbers should not equal 4/7 <> 2', function () {
            calc.divideTwoNumbers(4, 7).should.not.equal(2);
        });
        it('divide by 0 - should throw an error', function () {
           (function(){
                 calc.divideTwoNumbers(5, 0);
          }).should.throw();
        });
        it('should throw an error = "x" * "y"', function () {
            (function(){
                  calc.divideTwoNumbers("x","y");
           }).should.throw();
         });
    })
});

describe('Calculator', function () {
    
    describe('odd doubler', function () {
        
        it('should double when odd  3 = 9', function () {
            calc.oddDoubler(3).should.equal(9);
        });
        it('should not double when even  2 = 4', function () {
            calc.oddDoubler(2).should.not.equal(4);
        });
        it('should equal zero when even 8 => 0', function () {
            calc.oddDoubler(8).should.equal(0);
        });
    })
});