
var divideTwoNumbers = function (x, y) {
    if(!isInteger(x) || !isInteger(y)) {
        throw new Error()
    }
    if(y == 0) {
        throw new Error("cannot divide by zero")
    }
    return x / y;
}

var oddDoubler = function (x) {
    if(x % 2) {
        return x * x;
    }
    else {
        return 0;
    }
}
var isInteger = function (param) {
    return Number.isInteger(param);
}
module.exports = {
    divideTwoNumbers: divideTwoNumbers,
    oddDoubler: oddDoubler
}