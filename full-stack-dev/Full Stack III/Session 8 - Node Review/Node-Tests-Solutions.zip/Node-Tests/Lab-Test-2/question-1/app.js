var calc = require('./calculator')

console.log('divide two numbers 12 / 3 = ' + calc.divideTwoNumbers(12, 3));
console.log('odd doubler : 3 =' + calc.oddDoubler(3))