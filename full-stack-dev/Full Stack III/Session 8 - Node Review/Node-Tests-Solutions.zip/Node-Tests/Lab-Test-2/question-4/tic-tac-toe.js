var events = require('events');
var moment = require('moment');
var emitter = new events.EventEmitter();

var count = 0;

var getTime = function () {
    var d = new Date();
    return moment(d).format('hh:mm:ss a');
}
var ticHandler = function () {
  
    console.log('Tic!' + '-- Count: ' + count + ' -- Time: ' + getTime());
    setTimeout(function () {
        emitterHandler('Tac') 
    }, 1000);
}

var tacHandler = function () {
    console.log('Tac!' + '-- Count: ' + count + ' -- Time: ' +  getTime());
    setTimeout(function () {
        emitterHandler('Toe')
     } , 1000);
}
var toeHandler = function () {
    console.log('Toe!' + '-- Count: ' + count + ' -- Time: ' +  getTime());
    setTimeout(function () {
        emitterHandler('Tic')
     } , 1000);
}
var emitterHandler = function (type) {
    if(count === 15) {
        console.log('Game Over!');
        return;
    }
    count++;
    emitter.emit(type);
}
emitter.on('Tic', ticHandler);
emitter.on('Tac', tacHandler);
emitter.on('Toe', toeHandler);

emitter.emit('Tic');