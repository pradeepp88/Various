var events = require('events');
var moment = require('moment');
var emitter = new events.EventEmitter();

var count = 0;

var getTime = function () {
    var d = new Date();
    return moment(d).format('hh:mm:ss a');
}
var pingHandler = function () {
  
    console.log('Ping!' + '-- Count: ' + count + ' -- Time: ' + getTime());
    setTimeout(function () {
        emitterHandler('Pong') 
    }, 1000);
}

var pongHandler = function () {
    var waitTime = new Date().toTimeString();
    console.log('Pong!' + '-- Count: ' + count + ' -- Time: ' +  getTime());
    setTimeout(function () {
        emitterHandler('Ping', waitTime)
     } , 1000);
}

var emitterHandler = function (type) {
    if(count === 50) {
        console.log('Game Over!');
        return;
    }
    count++;
    emitter.emit(type);
}
emitter.on('Ping', pingHandler);
emitter.on('Pong', pongHandler);

emitter.emit('Ping');