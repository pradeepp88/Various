var http = require('http');
var info = require('./osinfo');

http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json'});

  if(req.url === '/') {
    res.end('No data found');
  }
  else if(req.url === '/api/systeminfo') {

    var sysinfo = info.systemModule.systemInfo;
    console.log(sysinfo());

    res.end(JSON.stringify(sysinfo()));
  }
  else if(req.url === '/api/userinfo') {

    var userinfo = info.systemModule.userInfo;
    console.log(userinfo());

    res.end(JSON.stringify(userinfo()));
  }
  else if(req.url === '/api/firewall') {
    var statuses = info.firewallModule.getStatues();
    console.log(statuses);

    res.end(JSON.stringify(statuses));
  }
  else {
        // request not found, send back 404
        res.writeHead(404, 'error - page not found');
        res.end();
  }
  
}).listen(1337, '127.0.0.1');