var os = require('os');


var systemInfo = function () {
    var arch = 'CPU architecture: ' + os.arch();
    var hostname = 'Host name: ' + os.hostname();
    var osname = 'OS name: ' + os.type();

    return 'Operating System Info: ' + arch + '-' + hostname + '-' + osname;
}

var userInfo = function () {
    var userInfo = os.userInfo();
    var username = 'User name: ' + userInfo.username;
    var homedir = 'Home dir: ' + userInfo.homedir;
    return 'User Info: ' + username  + '-' + homedir;
}
module.exports = {
    systemInfo: systemInfo,
    userInfo: userInfo
}
//console.log('Returns information about the current user ')
//console.log(os.userInfo())