var systemModule = require('./systeminfo');
var firewallModule = require('./firewall');

module.exports = {
    systemModule: systemModule,
    firewallModule: firewallModule
}