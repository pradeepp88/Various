
module.exports.getStatues = function () {
    return ['OK', 'ALLOW', 'DENY', 'BLOCK']
}