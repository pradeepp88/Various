// require built-in file system module
var fs = require('fs');
var zlib = require('zlib')

var gzip = zlib.createGzip();

const inp = fs.createReadStream('output.txt');
const out = fs.createWriteStream('output.txt.gz');

inp.pipe(gzip).pipe(out);

