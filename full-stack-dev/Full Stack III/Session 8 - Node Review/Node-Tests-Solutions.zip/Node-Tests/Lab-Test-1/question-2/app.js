// require built-in file system module
var fs = require('fs');
var zlib = require('zlib')

var gzip = zlib.createGzip();

var rs = fs.createReadStream("data.txt");
var ws = fs.createWriteStream("output.txt");


rs.on("data", function(data) {
    console.log(data);
    console.log(data.toString());
    ws.write(data);
})

rs.on("end", function () {
    ws.close();
    console.log('\nwrite is completed!');
})


const inp = fs.createReadStream('output.txt');
const out = fs.createWriteStream('output.txt.gz');

inp.pipe(gzip).pipe(out);



