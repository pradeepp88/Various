
var handlerCall = function () {
    console.log('call me sometime?');
}

var saturdayNightCall = (function(callback)) {
    callback(); // invoke (call)
}

saturdayNightCall(handlerCall);

if(condition) execute;

if(condition) {
    execute;
}