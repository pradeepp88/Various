
var fs = require('fs');
const path = require('path');
const directory = process.cwd() + '\\Logs';


// create 10 log files in directory
const createLogFiles = () => {
    // ** change process to current directory
    process.chdir(directory);

    for(i=0; i < 10; i++) {
        fs.writeFileSync(`log${i}.txt`, `this is a log file`);
        }
        fs.readdir(directory, (err, files) => {
            if (err) throw err;
            files.forEach(f => console.log(f))
        })
}


// make new directory and call create log files
if(!fs.existsSync(directory)) {
    fs.mkdirSync(directory);
}
    createLogFiles();


