
var fs = require('fs');
const path = require('path');
const directory = process.cwd() + '\\Logs';

// remove all files in the directory
const removeDirFiles = () => {
    var p = new Promise((resolve, reject) => {
        console.log(directory)
        fs.readdir(directory, (err, files) => {
            console.log(files)
            if (err) reject(err);

            for (const file of files) {
              console.log('delete files...' + file) 
              fs.unlinkSync(path.join(directory, file), err => {
                if (err) reject(err);
              });

            }
          });
          resolve();
    })
    
    return p;
}
// directory exists, remove the log files
if(fs.existsSync(directory)) {
    console.log('removing files..')
    removeDirFiles()
      .then(() => fs.rmdirSync(directory));
   }