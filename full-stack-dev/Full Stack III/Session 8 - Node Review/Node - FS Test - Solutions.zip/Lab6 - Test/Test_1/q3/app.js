const delayedPromise = (num) => {
    p = new Promise((resolve, reject) => {
      setTimeout(() => {
         resolve(num * num)
      }, 500);
    })
    return p
  }

  const delayedPromise2 = (num) => {
    p = new Promise((resolve, reject) => {
      setTimeout(() => {
         resolve(num * num)
      }, 500);
    })
    return p
  }

  var promises = [delayedPromise(6), delayedPromise2(7)];

  // resolve both promises
  Promise.all(promises)
  .then(function(values) {
   console.log(values)
})


