
const mixedArray = ['Matrix', 1, true, 2, false, 3]

const isNumber = (val) => { return typeof val === 'number' }

const multiplyFive = (el) => {  return el * 5; }

const multiplyNumbers = (array) => {
    return new Promise((resolve, reject) => {
      if(array) {
        var result = array.filter(isNumber).map(multiplyFive);
        resolve(result);
      } else {
        reject(`Error: multiplying mixed array. `) 
      }
  })
 } 
   

   multiplyNumbers(mixedArray)
    .then((result) => console.log(result))
    .catch(error => console.log(error))
  