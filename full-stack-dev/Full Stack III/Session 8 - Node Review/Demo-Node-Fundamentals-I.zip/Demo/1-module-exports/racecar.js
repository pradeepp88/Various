// constructor function for the Car class
function Car(name) {  
    this.miles = 0;
    this.name = name;
}

// now we export the class, so other modules can create Car objects
module.exports = {  
    Car: Car
}