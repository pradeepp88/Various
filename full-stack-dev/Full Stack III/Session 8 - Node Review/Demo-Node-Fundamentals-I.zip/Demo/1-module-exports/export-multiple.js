var lang = require('./languages');

console.log(lang.English);
console.log(lang.Spanish);
