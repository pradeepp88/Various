// import the cat module
var car = require('./racecar');  
var Car = car.Car;

// creates some car
var racecar = new Car("Dodge Carger");  
var racecar2 = new Car("Corvette");


console.log("There are two cars in the race, " + racecar.name + " and " + racecar2.name + ".");  
console.log("The first car has " + racecar.miles + " total miles " +  "and second car has " + racecar2.miles + " total miles");  