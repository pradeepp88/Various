
var e = require('./english');
var f = require('./french');
var s = require('./spanish');

module.exports = {
    English : e,
    French: f,
    Spanish: s
}