var books = require('./books.js');

console.log('Author: ' + books.favoriteAuthor.name + ' - Genre: ' + books.favoriteAuthor.genre);
console.log('Favorite Book: ' + books.favoriteBook().title + ' - Author: ' + books.favoriteBook().author);

