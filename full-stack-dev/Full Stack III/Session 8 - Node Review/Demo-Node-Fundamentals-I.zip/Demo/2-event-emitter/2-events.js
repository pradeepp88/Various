var d = require('./processData');

var r = d.processData(5);

r.on('start', function () {
    console.log('started!');
})

r.on('data', function (d) {
    console.log("data received --> " + d);
})

r.on('end', function () {
    console.log('ended!');
})