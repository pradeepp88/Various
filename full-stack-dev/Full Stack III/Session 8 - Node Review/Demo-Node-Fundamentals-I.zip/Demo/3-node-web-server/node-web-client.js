var http = require('http');

//var options = { host: 'www.georgebrown.ca', port: 80, path: '/', methond: 'GET'}

var req = http.request('http://www.georgebrown.ca/', function (response) {
	console.log(response.statusCode);
	response.pipe(process.stdout);
});

req.end();