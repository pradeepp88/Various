
var dater = function () {
    var result = new Date();
    console.log(result);
    return result;
}

module.exports = dater;