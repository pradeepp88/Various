
var mongoose = require('mongoose');

const connectionString =
"mongodb://localhost:27017/mongoose-demo?readPreference=primary&appname=MongoDB%20Compass&ssl=false";

mongoose.connect(connectionString, {
  })
    .then(
        () => console.log("Mongoose connected successfully "),
        (error) => console.log("Mongoose could not connected to database : " + error)
  );


var Schema = mongoose.Schema;

/// SCHEMA 
var customerSchema = new Schema({
    name: String,
    address: String,
    status: String
});

/// MIDDLE WARE HOOK
customerSchema.post('save', () => console.log('****** customer saved ******'));

// MODEL 
var Customer = mongoose.model('Customer', customerSchema);
var mike = Customer({ name: 'Mike', address: '219 Gretzky Way.'});

// SAVE USER TO MONGO DB
mike.save(function(err) {

  if (err) throw err;

  console.log('**** Mike was saved! *****');
});
