
var mongoose = require('mongoose');

const connectionString =
"mongodb://localhost:27017/mongoose-demo?readPreference=primary&appname=MongoDB%20Compass&ssl=false";

const handleSuccess = () => console.log("Mongoose connected successfully ");
const handleError =  (error) => console.log("Mongoose could not connected to database : " + error);


mongoose.connect(connectionString, {
  }).then(
        handleSuccess,    // asdfsadfdf
        handleError
  );

  const handleDisconnect = () => {
    mongoose.disconnect((err)=> console.log(`disconnecting..`))
  }
  setTimeout(handleDisconnect, 5000)
   ///asdfsdf