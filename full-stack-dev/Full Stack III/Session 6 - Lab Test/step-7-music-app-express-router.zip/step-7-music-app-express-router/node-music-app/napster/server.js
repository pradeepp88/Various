var express = require('express'),
  musicFactory = require('./modules/musicFactory'),
  socketManager = require('./modules/socketManager'),
  path = require('path'),
  bodyParser = require('body-parser'),
  mongoose = require("mongoose"),
  app = express();

  //////////DATABASE CONNECTION//////////
  const connectionString =
    "mongodb://localhost:27017/napster-music-app?readPreference=primary&appname=MongoDB%20Compass&ssl=false";

mongoose
  .connect(connectionString, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(
    () => {
      console.log("Mongoose connected successfully ");
    },
    (error) => {
      console.log("Mongoose could not connected to database : " + error);
    }
  );

//////////PORT CONNECTION//////////
var server = app.listen(3006, () => {
  console.log('web server listening on port 3006!')
})


app.use(express.static(path.join(__dirname, 'public')))

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())


socketManager.init(server);

app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname + '/napster.htm'));
})

app.use('/search', require('./routes/Search'));