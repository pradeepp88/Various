//// Constants and variables


let favoriteData = [];
let searchResultsContainer = null;
let favoriteListContainer = null;
let txtGenre = null;
let txtArtist = null;
let txtSong = null;
let txtAlbum = null;
let socket;
let hostUrl = 'http://localhost:3006';

/// SOCKET IO NETWORKING
const setupSocket = () => {
 
    socket = io(hostUrl)

    socket.on('connect', () => { console.log('SOCKET - connected'); });
    socket.on('disconnect', () =>{ console.log("SOCKET - disconnected"); });
    socket.on('download-received', (id) => console.log(`SOCKET - download received from server with id: ${id}`))
};

const hasSearchFilters = () => {
    return txtArtist.value || txtSong.value || txtAlbulm.value || txtGenre.value;
}


//// EVENT HANDLERS

const handleDownloadClick = (id) => {
    socket.emit('download', id)
}
const handleSearch = () => {
    console.debug('handle search');

    filterAndLoadResults();
}

const handleInputKeyUp = (e) => {
    console.debug('handle input key up');
    // Number 13 is the "Enter" key on the keyboard
  if (e.keyCode === 13) {
    // Cancel the default action, if needed
    e.preventDefault();

    filterAndLoadResults();
  }
}

const filterAndLoadResults = () => {

    if(!hasSearchFilters()) {
        alert('Please select a search filter');
        return;
    }
    
    const genre = txtGenre.value;
    const artist = txtArtist.value;
    const title = txtSong.value;
    const albulm = txtAlbulm.value;

    const request = new Request(`${hostUrl}/search/filtermusic?genre=${genre}&artist=${artist}&title=${title}&albulm=${albulm}`);

    fetch(request)
        .then(function(response) {
            return response.json();
        })
        .then(function (res) {
             loadData(res);
        })
        .catch(err => {
            console.error(err)
        });
}
const handleReset = () => {
    txtGenre.value = null;
    txtArtist.value = null;
    txtSong.value = null;
}


const handleFavoriteClick = (id) => {
    
    const request = new Request(`${hostUrl}/search/favorite?id=${id}`);
    var song = null;
    fetch(request)
        .then(function(response) {
            return response.json();
        })
        .then(function (res) {
            console.debug(res)
            song = res;

            if(!song) {
                console.warn(`song ${id} not found, cannot add to favorties`);
                 return;
             }
             favoriteData.push(song);
             createFavoriteImage(song); 
        })
        .catch(err => {
            console.error(err)
        });
}

const handleRemoveFavoriteClick = (e) => {
    if(!e.target) {
        return;
    }
    favoriteListContainer.removeChild(e.target);
}
const handleSongButtonClick = (e) => {
    if(!e.target) {
        return;
    }
    const id = e.target.getAttribute("data-key");

    if(e.target.className === 'btn-favorite') {
        handleFavoriteClick(id);
    }
    else if (e.target.className === 'btn-download') {
        handleDownloadClick(id);
    }
      

    console.debug(`selected row with song id : ${e.target.getAttribute("data-key")}`);
    
}
const setupHandlers = () => {
    getElement('#btnSearch').addEventListener('click', handleSearch);
    getElement('#btnReset').addEventListener('click', handleReset);
    getAllElements('input')
                .forEach(input => input.addEventListener('keyup', handleInputKeyUp));

    getElement('#searchResults').addEventListener('click', handleSongButtonClick);
    getElement('#favoriteListContainer').addEventListener('click', handleRemoveFavoriteClick);
}


const loadData = (data) => {
    removeTableRows();

    for(const song of data) {
        const songRow = buildTableRow(song);
        searchResultsContainer.append(songRow);
    }
}

//// DOM Manipulation & Traversal /////
const getElement = (selector) => {
    return document.querySelector(selector);
}
const getAllElements = (selector) => {
    return document.querySelectorAll(selector);
}

const removeTableRows = () => {
    while(searchResultsContainer.firstChild) {
        searchResultsContainer.removeChild(searchResultsContainer.firstChild);
    }
}

const buildTableRow = (songObj) => {
    const row = createElement('tr');
    for(const key in songObj){
        if(key === 'id' || key === 'imageName') continue;
        const colTitle = createElement('td', songObj[key]);
        row.append(colTitle);
    }
    const liFaDownload = createElement('li', null, "fas fa-download");
    createButtonColumn(row, 'Favorite', 'btn-favorite', songObj.id, liFaDownload);
    createButtonColumn(row, 'Download', 'btn-download', songObj.id, liFaDownload);

    return row;
}


const createFavoriteImage = (song) => {

    const imageName = song[0].imageName;
    const imgFilePath = `images\\${imageName}`;
    const imgElement = createElement('img', null, 'favorite-albulm-item');
    imgElement.src = imgFilePath;
    favoriteListContainer.append(imgElement);

}

const createButtonColumn = (rowElement, text, className, key, innerHtml) => {
    const buttonCol = createElement('td', null, null, key);
    const btnElement = createElement('button', text, className, key, innerHtml);
    buttonCol.append(btnElement);

     rowElement.append(buttonCol);
}
const createElement = (element, text, className, key, innerHtml) => {
    let elm = document.createElement(element);
    if(text)
        elm.textContent = text;
    if(className)
        elm.className = className;
    if(key)
        elm.dataset.key = key; //setAttribute("data-num", i);
    if(innerHtml)
        elm.innerHtml = innerHtml.outerHtml;
    return elm;
}

const inititalize = () => {
    searchResultsContainer = document.querySelector('#searchResults');
    favoriteListContainer = document.querySelector('#favoriteListContainer')
    txtGenre = document.querySelector('#txtGenre');
    txtArtist = document.querySelector('#txtArtist');
    txtSong = document.querySelector('#txtSong');
    txtAlbum = document.querySelector('#txtAlbum');
}
/// Window Load
window.onload = () => {
    console.debug('window loaded..');
    setupHandlers();
    inititalize();
 
}

$( document ).ready(function() {
    setupSocket();
});