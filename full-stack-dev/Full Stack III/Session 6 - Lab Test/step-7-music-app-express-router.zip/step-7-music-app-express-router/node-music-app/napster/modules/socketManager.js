const io = require('socket.io'),
    SocketEvent = require('../models/SocketEvents'),
    DownloadEvent = require('../models/DownloadEvents')

const init = (server) => {

    var channel = io.listen(server);

    channel.on('connection', function(socket){
        // now we have a client object!
        console.log("Connection accepted.");

        var connectEvent=new SocketEvent({type:'CONNECTION', socket:socket.id})
        connectEvent.save((err)=>{
                if (err) throw err;
                     console.log('\n==========STORE EVENT IN DATABASE==========\nSocket: '+connectEvent.socket+'\nWith type: '+connectEvent.type+"\nHas been connected @: "+ connectEvent.eventTime)
            })
    
    socket.on('download', function(id){
        socket.emit('download-received', id)
        var downloadEvent=new DownloadEvent({socket:socket.id, songId: id})
        downloadEvent.save((err)=>{
                if (err) throw err;
                     console.log('\n==========STORE EVENT IN DATABASE==========\nDownload has started on socket: '+downloadEvent.socket+"\nwith song Id @: "+ downloadEvent.songId+"\nStored in database @: "+ downloadEvent.downloadTime)
            })
    });

    socket.on('disconnect', function(){
        var disconnectEvent=new SocketEvent({type:'DISCONNECT', socket:socket.id})
        disconnectEvent.save((err)=>{
                if (err) throw err;
                     console.log('\n==========STORE EVENT IN DATABASE==========\nSocket: '+disconnectEvent.socket+'\nWith type: '+disconnectEvent.type+"\nHas been disconnected @: "+ disconnectEvent.eventTime)
            })

    });
 
  });
}

module.exports =  { init: init };