const mongoose = require('mongoose');

const socketEvent = new mongoose.Schema({
    socket: String,
    type: String,
    eventTime: {type:Date, default:Date}
})
module.exports = mongoose.model("SocketEvent", socketEvent);