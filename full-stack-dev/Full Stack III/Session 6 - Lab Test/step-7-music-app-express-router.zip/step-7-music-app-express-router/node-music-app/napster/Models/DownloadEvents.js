var mongoose = require('mongoose');

var downloadEvent = new mongoose.Schema({
    socket: String,
    songId: String,
    downloadTime: {type:Date, default:Date}
})
module.exports = mongoose.model("DownloadEvent", downloadEvent);