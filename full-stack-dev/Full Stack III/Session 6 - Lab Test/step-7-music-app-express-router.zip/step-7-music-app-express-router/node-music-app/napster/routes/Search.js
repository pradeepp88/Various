const express = require('express');
const router = express.Router();
const musicFactory = require('../modules/musicFactory')

musicFactory.init();

router.get('/musicData', function(req, res) {
    const data = musicFactory.getMusicData();
    res.status(200);
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(data));
  })

router.get('/filterMusic', function(req, res) {
    const queryStr = req.query;
    console.debug(queryStr)
    const data = musicFactory.filterMusic(queryStr.genre, queryStr.band, queryStr.title, queryStr.albulm)
    res.status(200);
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(data));
  })

 router.get('/favorite', (req, res) => {
    const queryStr = req.query;
    console.log(queryStr)
    const song = musicFactory.addFavorite(queryStr.id);
    res.status(200);
    res.send(JSON.stringify(song));
  })

 router.post('/download', (req, res) => {
    const params = req.body;
    console.log(params);
    musicFactory.downloadSong(params.id);
    res.status(200);
    res.send(`Downloaded song with id: ${params.id}`);
  })


module.exports = router;