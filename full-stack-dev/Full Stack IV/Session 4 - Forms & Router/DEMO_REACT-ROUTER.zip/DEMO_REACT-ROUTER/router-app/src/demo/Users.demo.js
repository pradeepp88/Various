import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function Users() {
  const fetchItems = async () => {
    const data = await axios.get(`https://jsonplaceholder.typicode.com/users`);
    console.log(data.data);
  };
  return (
    <div>
      <h1>Users</h1>
      {items.map(item => (
        <h1 key={item.id}>
          <Link to={`users/${item.id}`}>{item.name}</Link>
        </h1>
      ))}
    </div>
  );
}

export default Users;
