import React from "react";
import axios from "axios";

function UserDetails({ match }) {
  
  const fetchItem = async () => {
    const item = await axios.get(
      `http://jsonplaceholder.typicode.com/users/${match.params.id}`
    );
    console.log(item.data);
  };
  return (
    <div>
      <h1>{item.name}</h1>
      <h2>{item.email}</h2>
    </div>
  );
}

export default UserDetails;
