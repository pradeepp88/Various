import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function Users() {
  // empty array, useEffect will only run once, on first render.
  // ComponentDidMount, UnMount
  useEffect(() => {
    fetchItems();
  }, []);

  const [items, setItems] = useState([]);

  const fetchItems = async () => {
    const data = await axios.get(`https://jsonplaceholder.typicode.com/users`);
    console.log(data.data);
    setItems(data.data);
  };

  return (
    <div>
      <h1>Users</h1>
      {items.map((item) => (
        <h1 key={item.id}>
          <Link to={`users/${item.id}`}>{item.name}</Link>
        </h1>
      ))}
    </div>
  );
}

export default Users;
