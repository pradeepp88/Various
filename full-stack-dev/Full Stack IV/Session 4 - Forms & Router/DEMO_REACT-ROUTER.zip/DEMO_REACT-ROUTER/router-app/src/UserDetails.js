import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function UserDetails({ match }) {
  // empty array, useEffect will only run once, on first render.
  useEffect(() => {
    fetchItem();
    console.log(match);
  }, []);

  const [item, setItem] = useState({});

  const fetchItem = async () => {
    const item = await axios.get(
      `http://jsonplaceholder.typicode.com/users/${match.params.id}`
    );
    console.log(item.data);
    setItem(item.data);
  };
  return (
    <div>
      <h1>{item.name}</h1>
      <h2>{item.email}</h2>
    </div>
  );
}

export default UserDetails;
