import React from "react";

function Repo() {
  return (
    <div>
      <h1>Git Repo</h1>
    </div>
  );
}

export default Repo;
