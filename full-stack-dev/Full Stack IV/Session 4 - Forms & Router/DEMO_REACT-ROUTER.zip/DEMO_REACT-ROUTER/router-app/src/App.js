import React from "react";
import Nav from "./Nav";
import Repo from "./Repo";
import Users from "./Users";
import UserDetails from "./UserDetails";

import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Router>
        <Nav />
        <Switch>
          <Route path="/" component={Home} exact />
          <Route path="/repo" component={Repo} />
          <Route path="/user" component={Users} />
          <Route path="/users/:id" component={UserDetails} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;

const Home = () => {
  return (
    <div>
      <h1>HOME</h1>
    </div>
  );
};
