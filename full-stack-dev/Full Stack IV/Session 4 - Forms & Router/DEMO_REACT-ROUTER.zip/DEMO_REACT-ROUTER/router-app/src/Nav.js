import React from "react";
import { Link } from "react-router-dom";
import "./App.css";

function Nav() {
  const navStyle = {
    color: "white"
  };
  return (
    <nav className="nav-bar">
      <ul className="nav-links">
        <Link to="/repo" className={navStyle}>
          <li>Repo</li>
        </Link>
        <Link to="/user" className={navStyle}>
          <li>Users</li>
        </Link>
      </ul>
    </nav>
  );
}

export default Nav;
