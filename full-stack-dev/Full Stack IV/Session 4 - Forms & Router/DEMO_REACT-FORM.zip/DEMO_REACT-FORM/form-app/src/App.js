import React from "react";
import "./App.css";

import NameFormBasic from "./Forms/NameFormBasic";
import EssayForm from "./Forms/EssayForm";
import FlavorForm from "./Forms/FlavorForm";
import NameForm from "./Forms/NameForm";
import RsvForm from "./Forms/ReservationForm";
import FormikForm from "./Forms/FormikForm";

function Frm() {
  return (
    <div>
      <input type="text" value="react" />
      <br />
      <textarea value="react" />
      <br />
      <select value="saturday">
        <option value="saturday">Saturday</option>
        <option value="sunday">Sunday</option>
      </select>
    </div>
  );
}

function App() {
  return (
    <div className="App">
      <br />
 
       <FormikForm />
    </div>
  );
}

export default App;
