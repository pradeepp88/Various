import React, { Component } from "react";
import "./App.css";
import StudentList from "./StudentList";

class App extends Component {
  render() {
    return (
      <>
        <StudentList />
      </>
    );
  }
}

export default App;
