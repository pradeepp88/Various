var array = [1, 2, 3, 4]

var calculateSum = array.reduce((acc, value) => acc + value, 0)
var calculateProduct = array.reduce((acc, value) => acc * value, 1)

var array = [1, 2, 3, 4]
// Code ..
console.log(calculateSum);
console.log(calculateProduct);
// Output
10
24
