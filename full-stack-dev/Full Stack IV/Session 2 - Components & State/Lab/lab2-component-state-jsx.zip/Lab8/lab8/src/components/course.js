import React from "react";

const Course = props => {
  return (
    <p>
      <b>Course {props.number}</b>
    </p>
  );
};

export default Course;
