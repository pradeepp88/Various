
import React from "react";

const Greeter = () => {
  return <h1>Hello World!</h1>;
};

export default Greeter;
