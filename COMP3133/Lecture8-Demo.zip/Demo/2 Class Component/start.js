<!DOCTYPE html>
<html>
    <head>
        <title>Click Counter</title>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/react/15.4.2/react.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/react/15.4.2/react-dom.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/6.21.1/babel.min.js"></script>
    </head>
    <body align="center">
   
        <div id="root"></div>
        
        <script type="text/babel">
        
            class Button extends React.Component {
             
              render() {
                return <button>5</button>;
              }
            }
            
            ReactDOM.render(
                <Button/>,
                document.getElementById("root")
            );
        </script>
  
    </body>
</html>