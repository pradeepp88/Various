<!DOCTYPE html>
<html>
    <head>
        <title>Click Counter</title>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/react/15.4.2/react.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/react/15.4.2/react-dom.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/6.21.1/babel.min.js"></script>
    </head>
    <body align="center">
   
        <div id="root"></div>
        
        <script type="text/babel">
        
            const Button = (props) => {
                
                return <button>{props.number}</button>;
            };
            
            ReactDOM.render(
                <Button number="5" />,
                document.getElementById("root")
            );
        </script>
  
    </body>
</html>